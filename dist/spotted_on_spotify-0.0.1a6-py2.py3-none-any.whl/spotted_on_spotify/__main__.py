#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""spotted_on_spotify.__main__: executed when spotted on spotify directory is called as script."""


from .spotted_on_spotify import main
main()
